#!/usr/bin/python

import os,sys
import string


def fatal():
    sys.exit()

class climateData:
    """A class for climate data""" 

    def __init__(self,filename):
        self.filename = filename
	self.dict = {}

    def split_by_length (self, input, size): #split a list into two according to the length
	w = []
	for i in range (0,len(input),size):
		w.append(input[i:i+size])
		return w, [input[size:]]


    # parse the input file and store the data
    # in an internal format. I suggest using 
    # a dictionary for mapping pairs of year
    # and month to climate data: (pcp, temp, pdsi)
    def parseFile(self):
    	    f = open (self.filename,'r')
	    lines = f.readlines();
	    counter = 0
	    for line in lines:
		    counter = counter + 1
		    if counter == 1:
			    continue
		    data = line.split()
		    [Year , Month] = self.split_by_length (data[2],4)  #establish mapping in dictionary
		    self.dict [(string.atoi(Year[0]),string.atoi(Month[0]))] =  \
		    (string.atof(data[3]),string.atof(data[4]),string.atof(data[5]))
	    
	    #use binary search to find an element, if not succeed, insert that into the dictionary.
	    #will be called in yearly report, since which years are to be read is unknown
	    
    def binary_search_insert (self,element,array): 
	    n = len(array)
	    high = n - 1
	    low = 0
	    mid = (low + high)/2
	    while low <= high:
		    if array[mid] == element:
			    return 0
		    elif array[mid] < element:
			    low = mid + 1
		    elif array[mid] > element:
			    high = mid - 1
		    mid = (low + high)/2
	    array.insert(mid + 1 , element)
	    return 1

    # report monthly average data
    def reportMonthlyAverage(self):
	    PCP_sum = [0] * 13
	    TMP_sum = [0] * 13
	    PDSI_sum = [0] * 13
	    PCP_average = [0] * 13
	    TMP_average = [0] * 13
	    PDSI_average = [0] * 13
	    m = [0] * 13
	    print "Reporting monthly average:"

	    for (x,y) in self.dict.keys():
		PCP_sum[y] = PCP_sum[y] + self.dict[(x,y)][0]
		TMP_sum[y] = TMP_sum[y] + self.dict[(x,y)][1]
		PDSI_sum[y] = PDSI_sum[y] + self.dict[(x,y)][2]
		m[y] = m[y] + 1
	    for i in range (1,13):
	    	PCP_average[i] = PCP_sum[i] / m[i]
	    	TMP_average[i] = TMP_sum[i] / m[i]
	    	PDSI_average[i] = PDSI_sum[i] / m[i]
		print "Month %d  average PCP: %.2f  average temperature: %.2f  average PSDI: %.2f" %\
		(i,PCP_average[i],TMP_average[i],PDSI_average[i])

    # report yearly data
    def reportYearlyData(self):
	    years = []
	    for (x,y) in self.dict.keys():
		    self.binary_search_insert(x,years)
	    NumYear = len(years)
	    PCP_sum = [0] * NumYear
	    TMP_sum = [0] * NumYear
	    PDSI_sum = [0] * NumYear
	    PCP_average = [0] * NumYear
	    TMP_average = [0] * NumYear
	    PDSI_average = [0] * NumYear
	    year = [0] * NumYear
	    NumDroughts = [0] * NumYear
	    print "Reporting yearly data:"

	    for (x,y) in self.dict.keys():
		PCP_sum[x-years[0]] = PCP_sum[x-years[0]] + self.dict[(x,y)][0]
		TMP_sum[x-years[0]] = TMP_sum[x-years[0]] + self.dict[(x,y)][1]
		if self.dict[(x,y)][2] < -3.0:
			NumDroughts[x-years[0]] += 1
		year[x-years[0]] = year[x-years[0]] + 1
	    for i in range (years[0],years[NumYear-1] + 1):
	    	PCP_average[i-years[0]] = PCP_sum[i-years[0]] / year[i-years[0]]
	    	TMP_average[i-years[0]] = TMP_sum[i-years[0]] / year[i-years[0]]
		print "Year %d   average PCP: %.2f inches   average temp: %.2f   num of droughts: %d" %\
		(i,PCP_average[i-years[0]],TMP_average[i-years[0]],NumDroughts[i-years[0]])

    # report decade long data
    def reportDecadeLongData(self):

	    years = []
	    for (x,y) in self.dict.keys():
		    self.binary_search_insert(x,years)
	    NumYear = len(years)
	    PCP_sum = [0] * (NumYear/10+1)
	    TMP_sum = [0] * (NumYear/10+1)
	    PDSI_sum = [0] * (NumYear/10+1)
	    PCP_average = [0] * (NumYear/10+1)
	    TMP_average = [0] * (NumYear/10+1)
	    PDSI_average = [0] * (NumYear/10+1)
	    year = [0] * (NumYear/10+1)
	    NumDroughts = [0] * (NumYear/10+1)
	    print "Reporting decade-long data:"

	    for (x,y) in self.dict.keys():
		PCP_sum[(x-years[0])/10] = PCP_sum[(x-years[0])/10] + self.dict[(x,y)][0]
		TMP_sum[(x-years[0])/10] = TMP_sum[(x-years[0])/10] + self.dict[(x,y)][1]
		if self.dict[(x,y)][2] < -3.0:
			NumDroughts[(x-years[0])/10] += 1
		year[(x-years[0])/10] = year[(x-years[0])/10] + 1
	    for i in range (years[0],years[NumYear-1] + 1):
	    	PCP_average[(i-years[0])/10] = PCP_sum[(i-years[0])/10] / year[(i-years[0])/10]
	    	TMP_average[(i-years[0])/10] = TMP_sum[(i-years[0])/10] / year[(i-years[0])/10]
	    for i in range (0 , (years[NumYear-1]-years[0])/10 + 1):
		print "Decade %d -- %d    average PCP: %.2f inches   average temp: %.2f   num of droughts: %d" %\
		(years[0]+10*i,years[0]+10*i+9,PCP_average[i],TMP_average[i],NumDroughts[i])

# the main program

if (len(sys.argv) > 1):
    filename = sys.argv[1]
else: 
    print 'Please give a file name that contains the climate data! Exiting ...'
    fatal()

g = climateData (filename)
g.parseFile()
g.reportMonthlyAverage()
g.reportYearlyData()
g.reportDecadeLongData()
