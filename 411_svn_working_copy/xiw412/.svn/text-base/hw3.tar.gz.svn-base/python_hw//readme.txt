/***************************
*Author: Xin Wang
*Data: 09/21/2012
****************************

Usage Guidance:
--To execute the python file, please use "python climate_template.py PA-1900-2009.txt" or
"./climate_template.py PA-1900-2009.txt > PA-result.txt" and compare the result file with the professor
gave us
--To read results, please open files "vim *-result.txt"
--To get new data, please use "wget *(website)" and deal with this file with climate_template.py

My conclusion:

From the data in the last ten decades in north east central region, southeast region, central region and New York State, we can see trend in variation of global warming, either a up-going one or one fitting polynomial regression. However, there is no trend of more droughts in even one of these areas.

For more details of my analysis, please read Analysis.pdf.
