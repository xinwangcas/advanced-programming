/********************************************************
 This program calculates the Pearson, Spearman and 
 Kendall correlation coefficients. 
 The inputs are two numbers per line, separated by a space
 The program has taken ties into consideration.
*********************************************************/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

/********************************************************
                       Pearson
*********************************************************/
double pearson( int a[] , int b[] )
{
	int i;
	double rho;
	double s1 = 0.0;
	double s2 = 0.0;
	double s3 = 0.0;
	double a_avg = 0.0;
	double b_avg = 0.0;
	for ( i = 0 ; i <= 4 ; i ++ )
	{
		a_avg = a_avg + a[i];
		b_avg = b_avg + b[i];
	}
	a_avg = a_avg / 5;
	b_avg = b_avg / 5;
	for ( i = 0 ; i <= 4 ; i ++ )
	{
		s1 = s1 + ( a[i] - a_avg ) * ( b[i] - b_avg );
		s2 = s2 + ( a[i] - a_avg ) * ( a[i] - a_avg );
		s3 = s3 + ( b[i] - b_avg ) * ( b[i] - b_avg );
	}
	rho = s1 / (( sqrt (s2) ) * ( sqrt (s3) ));
	return rho;
}
/********************************************************
Spearman:
use structs array_a & array_b to combine the original 
index of arrays to the data, so as to trace back
after sorting by bubble sort. 
*********************************************************/
	struct array
	{
           double data;
           int index;
    } array_a[5] , array_b[5];

double spearman( int a[] , int b[] )
{
    int i;
    int j;
    double temp1;
    int temp2;
	double rho;
	double s1 = 0.0;
	double s2 = 0.0;
	double s3 = 0.0;
	double a_avg = 0.0;
	double b_avg = 0.0;
	int rank_a[5];
	int rank_b[5];
    
    for ( i = 0 ; i <= 4 ; i ++ )
    {
        array_a[i].data = a[i];
        array_a[i].index = i;
        array_b[i].data = b[i];
        array_b[i].index = i;
    }
    
	for ( i = 0 ; i < 4 ; i ++ )
	{
        for ( j = 0 ; j < 4 - i ; j ++ )
        {
            if ( array_a[j].data > array_a[j+1].data )
            {
                 temp1 = array_a[j].data;
                 array_a[j].data = array_a[j+1].data;
                 array_a[j+1].data = temp1;
                 temp2 = array_a[j].index;
                 array_a[j].index = array_a[j+1].index;
                 array_a[j+1].index = temp2;
            }
        }
    }
    
	for ( i = 0 ; i < 4 ; i ++ )
	{
        for ( j = 0 ; j < 4 - i ; j ++ )
        {
            if ( array_b[j].data > array_b[j+1].data )
            {
                 temp1 = array_b[j].data;
                 array_b[j].data = array_b[j+1].data;
                 array_b[j+1].data = temp1;
                 temp2 = array_b[j].index;
                 array_b[j].index = array_b[j+1].index;
                 array_b[j+1].index = temp2;
            }
        }
    }
    
    for ( i = 0 ; i <= 4 ; i ++ )
    {
            rank_a[i] = i + 1;
            rank_b[i] = i + 1;
//            array_a[i].data = rank_a[i];
//            array_b[i].data = rank_b[i];
    }
    
    for ( i = 0 ; i < 4 ; i ++ )
    {
        double sum = 0.0;
        if (array_a[i].data != array_a[i+1].data)
        array_a[i].data = rank_a[i];
        else
        {
            for ( j = i ; (j < 4)&&(array_a[j].data == array_a[j+1].data) ; j ++ )
            {
                sum = sum + rank_a[j];
            }
            if (j < 4)
            {
                  sum = sum + rank_a[j];
            }
            else if ( (j == 4)&& (array_a[j].data == array_a[j-1].data))
                 sum = sum + rank_a[j];
            else if (( j == 4)&&(array_a[j].data != array_a[j-1].data))
                 sum = sum;
            sum = sum / (j - i + 1);
            for (int m = i ; m <= j ; m ++ )
                array_a[m].data = sum;
            i = j;
        }
    }
    
    if (array_a[4].data != array_a[3].data)
       array_a[4].data = rank_a[4];
    
    for ( i = 0 ; i < 4 ; i ++ )
    {
        double sum = 0.0;
        if (array_b[i].data != array_b[i+1].data)
        array_b[i].data = rank_b[i];
        else
        {
            for ( j = i ; (j < 4)&&(array_b[j].data == array_b[j+1].data) ; j ++ )
            {
                sum = sum + rank_b[j];
            }
            if (j < 4)
            {
                  sum = sum + rank_b[j];
            }
            if ( (j == 4)&& (array_b[j].data == array_b[j-1].data))
                 sum = sum + rank_b[j];
            else if ((j == 4)&&(array_b[j].data != array_b[j-1].data))
                 sum = sum;
            sum = sum / (j - i + 1);
            for (int m = i ; m <= j ; m ++ )
                array_b[m].data = sum;
            i = j;
        }
    }
    if (array_b[4].data != array_b[3].data)
       array_b[4].data = rank_b[4];
        
	for ( i = 0 ; i <= 4 ; i ++ )
	{
		a_avg = a_avg + array_a[i].data;
		b_avg = b_avg + array_b[i].data;
	}
	a_avg = a_avg / 5;
	b_avg = b_avg / 5;

	for ( i = 0 ; i <= 4 ; i ++ )
	{
        for ( j = 0 ; j <= 4 ; j ++ )
        {
            if (array_a[i].index == array_b[j].index)
            {
                                 s1 = s1 + ( array_a[i].data  - a_avg ) * ( array_b[j].data - b_avg );
                                 s2 = s2 + ( array_a[i].data  - a_avg ) * ( array_a[i].data  - a_avg );
                                 s3 = s3 + ( array_b[j].data  - b_avg ) * ( array_b[j].data  - b_avg ) ;               
            }
        }

	}
	rho = s1 / sqrt ( s2 * s3);
	return rho;
}

int sgn ( double d )
{
	if ( d < 0 ) 
		return -1;
	else if ( d == 0 )
		return 0;
	else
		return 1;
}

double kendall ( int a[], int b[] )
{
	double n1 = 0.0;
	double n2 = 0.0;
	double n3 = 0.0;
	double n0 = ( 5 * ( 5 - 1 )) / 2 ;
	double tao;
	double t[5] = { 1 , 1 , 1 , 1 , 1 };
	double u[5] = { 1 , 1 , 1 , 1 , 1 };
	int i,j,m;
	
    for ( i = 0 ; i < 4 ; i ++ )
	{
        
	    for ( j = i + 1 ; j <= 4 ; j ++ )
        {
		        n3 = n3 + sgn ( a[i] - a[j] ) * sgn ( b[i] - b[j] );
        }
    }
    
	for ( i = 0 ; i < 4 ; i ++ )
	{
        if ( t[i] == 1 )
        {
             for ( j = i + 1 ; j <= 4 ; j ++ )
             {
			        if ( sgn ( a[i] - a[j] == 0 ))
                         t[i] ++ ;
             }
             
             for ( m = i ; m <= i + t[i] - 1 ; m ++ )
                    t[m] = t[i];
             n1 = n1 + t[i] * ( t[i] - 1 ) / 2 ; 
        }
     }
     
	for ( i = 0 ; i < 4 ; i ++ )
	{
        if ( u[i] == 1 )
        {
             for ( j = i + 1 ; j <= 4 ; j ++ )
             {      
			        if ( sgn ( b[i] - b[j] == 0))
                         u[i] ++ ;
             }

             for ( m = i ; m <= i + u[i] - 1 ; m ++ )
                    u[m] = u[i];

             n2 = n2 + u[i] * ( u[i] - 1 ) / 2 ;    
        }
	}
	
	tao = n3 / sqrt( ( n0 - n1 ) * ( n0 - n2 ) );
	return tao;
}

int main()
{
	double coe_p;
	double coe_s;
	double coe_k;
	int a[5];
	int b[5];
/*	a[0] = 1;
	a[1] = 4;
	a[2] = 2;
	a[3] = 9;
	a[4] = 3;
	b[0] = 2;
	b[1] = 8;
	b[2] = 4;
	b[3] = 1;
	b[4] = 6;*/
	for ( int i = 0 ; i <= 4; i ++ )
	{
        scanf("%d",&a[i]);
        scanf("%d",&b[i]);
    }
	coe_p = pearson(a,b);
	coe_k = kendall(a,b);
	coe_s = spearman(a,b);
	printf("The pearson coefficient is: %f\n", coe_p);
	printf("The spearman coefficient is: %f\n", coe_s);
	printf("The kendall coefficient is: %f\n", coe_k);
	
//	system("pause");
	return 0;
}
