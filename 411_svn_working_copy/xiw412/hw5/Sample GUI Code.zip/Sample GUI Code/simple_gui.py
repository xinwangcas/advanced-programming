#!/opt/ActivePython-2.7/bin/python

# simple_gui.py

from Tkinter import *

root = Tk()
root.title("Simple GUI")
root.geometry("200x100")

root.mainloop()
