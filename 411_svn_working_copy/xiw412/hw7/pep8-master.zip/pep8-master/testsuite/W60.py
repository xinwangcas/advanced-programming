#: W601
if a.has_key("b"):
    print a
#: W602
raise DummyError, "Message"
#: Okay
raise type_, val, tb
#: W603
if x <> 0:
    x = 0
#: W604
val = `1 + 2`
