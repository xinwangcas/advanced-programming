Program for counting word frequency in a file

- q1NOTSUNLAB.cpp - implements question one without commandline processing for original error checking

- q1.cpp - uses the commandline processing

- q2.cpp - parallel version.  Testing cut short because lab overload

-q3.cpp - moves files to /temp/ker212/ on each machine, then counts their most frequent words

-q4.cpp - downloads text from websites to /temp/ker212/ to be counted and processed 

files q2-4 all have timing functionality. However, I was unable to complete the testing because of the system overload.