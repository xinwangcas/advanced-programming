#include<iostream>
#include<fstream>
#include<map>
#include<string>
#include<list>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<unistd.h>
#include<getopt.h>

using namespace std;
string cleanup(string input){ // function to set all strings to lowercase and remove punctuation.  
	bool end_in_whitespace = false;
	for (int i=0;i<input.length();i++)
	{
		input[i]=tolower(input[i]);
	}

	int len = input.length()-1;
//	cout<<input<<" "<<input[len]<<endl;
		if (input[len]<'0')
			input = input.substr(0,len);
		else if (input[len]>'9' && input[len]<'a')
			input = input.substr(0,len);
		else if (input[len]>'z')
			input = input.substr(0,len);

	return input;
}
void readNcount(ifstream &inFile, map<string,int> &allWords){ //function that reads in file and counts unique words as read in
	allWords.clear(); //make sure that the map is empty
	string newWord;
	inFile>>newWord;								//priming read
	while(inFile){
		newWord=cleanup(newWord);					//tolower and remove punct.
	//	cout<<newWord<<endl;
		if(allWords.find(newWord)!=allWords.end()){ //if newly read in word is already in map
			allWords[newWord]++; //incriment to number of times the word appears
	//		cout<<allWords[newWord]<<endl;
		}
		else{ //map is empty or the word does not exist in the map yet
			allWords.insert(pair<string,int>(newWord,1)); //add new word with 1 instance
	//		cout<<allWords[newWord]<<endl;
		}
		inFile>>newWord;
	}
}
void rankWords(map<string,int> &allWords, map<int,list<string> > &rankedWords){ //function to rank words by frequency
	//map will sort items in order (alpha, numeric, etc.) by key, so if we reverse the map from <string, int> to be a <int, list<string>>, we can 
	//get the items sorted by the map in order of term frequency, handling the instance where multiple words have the same freq.
	//the lists will populate in alpha order because the allWords map is in alpha order
	map<string,int>::const_iterator mIT;
	for(mIT= allWords.begin(); mIT!=allWords.end(); mIT++){
		if(rankedWords.find(mIT->second)!=rankedWords.end()){ //if the ranking map already contains the value
			rankedWords[mIT->second].push_back(mIT->first);
		}
		else{ //either ranked map is empty or the values does not exist yet
			list<string> tempList;
			tempList.push_back((*mIT).first);
			rankedWords[mIT->second]= tempList;
			//rankedWords.insert(pair<int,list<string>>((*mIT).second,tempList));
		}
	}
}
void outputTopN(map<int,list<string> > &rankedWords, int N, string fileName){  //function to output top N most frequent words from the rank map
	int numOutput = 0;										 //must keep track because it may not be equal to the number of pairs in the map
	map<int, list<string> >::reverse_iterator rIT;
	list<string>::const_iterator lIT;
	bool inLoop=false;										 //indicates if the inner loop was broken
	for(rIT=rankedWords.rbegin(); rIT!=rankedWords.rend(); rIT++){  //backward because we want the higest value first
		for(lIT=rIT->second.begin(); lIT!=rIT->second.end(); lIT++){  //outputting the list alphabetically
			cout<<fileName<<","<<*lIT<<","<<rIT->first<<endl;
			numOutput++;
			if(numOutput>=N){
				inLoop=true;
				break;
			}
		}
		if(inLoop==true){
			break;
		}
	}
}
int s2i(string a){
	std::string myString = a;
	int value = atoi(myString.c_str());
	return value;
}
int main(int argc, char* argv[]){
	//followed getopt example from http://www.ibm.com/developerworks/aix/library/au-unix-getopt.html 
	//and ftp://ftp.cs.uregina.ca/pub/class/330/IOandArgs/ioandargs.html 
	int numInputFiles = 0;
	int N;
	string dirName;
	int hasDir=0;
	vector<string> fileNames;

	static char optstring[] = "n:?d:";
	int c;
	while((c = getopt(argc, argv, optstring)) != -1){
		cout<<"in while"<<endl;
		switch(c){
		case 'n':
			N= s2i(optarg);
			break;
		case 'd':
			hasDir=1;
			dirName = optarg;
			break;
		case '?':
			break;
		default:
			break;
		}
		while(optind < argc){
			fileNames.push_back(argv[optind]);
			numInputFiles++;
			optind++;
		}
	}

	ifstream inFile;
	map<string,int> allwords;
	map<int,list<string> > rankedWords;
	std::string curFile=" ";
	for(int i=0; i<numInputFiles; i++){
		curFile=fileNames[i];
		inFile.open(curFile.c_str(), ifstream::in);
		readNcount(inFile,allwords);
		rankWords(allwords,rankedWords);
		outputTopN(rankedWords, N, curFile);
	}

	return 0;

}
