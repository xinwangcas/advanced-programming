//#include<iostream>
#include<fstream>
#include<map>
#include<string>
#include<sstream>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<unistd.h>
#include<getopt.h>
#include<cstdlib>
#include<mpi.h>
#include<dirent.h>



using namespace std;
string i2s(int in){  //function to convert int to string
	stringstream ss;
	ss<<in;
	string out;
	out = ss.str();
	return out;
}
string cleanup(string input){ // function to set all strings to lowercase and remove punctuation. 
	bool end_in_whitespace = false;
	for (int i=0;i<input.length();i++)
	{
		input[i]=tolower(input[i]);
	}

	int len = input.length()-1;
//	cout<<input<<" "<<input[len]<<endl;
		if (input[len]<'0')
			input = input.substr(0,len);
		else if (input[len]>'9' && input[len]<'a')
			input = input.substr(0,len);
		else if (input[len]>'z')
			input = input.substr(0,len);

	return input;
}
void readNcount(ifstream &inFile, map<string,int> &allWords){ //function that reads in file and counts unique words as read in
	cout<<"IN READNCOUNT"<<endl;
	allWords.clear(); //make sure that the map is empty
	string newWord;
	inFile>>newWord;								//priming read
	while(inFile){
		newWord=cleanup(newWord);					//tolower and remove punct.
	//	cout<<newWord<<endl;
		if(allWords.find(newWord)!=allWords.end()){ //if newly read in word is already in map
			allWords[newWord]++; //incriment to number of times the word appears
	//		cout<<allWords[newWord]<<endl;
		}
		else{ //map is empty or the word does not exist in the map yet
			allWords.insert(pair<string,int>(newWord,1)); //add new word with 1 instance
	//		cout<<allWords[newWord]<<endl;
		}
		inFile>>newWord;
	}
}
void rankWords(map<string,int> &allWords, map<int,vector<string> > &rankedWords){ //function to rank words by frequency
	cout<<"IN RANK WORDS"<<endl;

	//map will sort items in order (alpha, numeric, etc.) by key, so if we reverse the map from <string, int> to be a <int, vector<string>>, we can 
	//get the items sorted by the map in order of term frequency, handling the instance where multiple words have the same freq.
	//the vectors will populate in alpha order because the allWords map is in alpha order
	map<string,int>::const_iterator mIT;
	for(mIT= allWords.begin(); mIT!=allWords.end(); mIT++){
		if(rankedWords.find(mIT->second)!=rankedWords.end()){ //if the ranking map already contains the value
			rankedWords[mIT->second].push_back(mIT->first);
		}
		else{ //either ranked map is empty or the values does not exist yet
			vector<string> tempvector;
			tempvector.push_back((*mIT).first);
			rankedWords[mIT->second]= tempvector;
			//rankedWords.insert(pair<int,vector<string>>((*mIT).second,tempvector));
		}
	}
}
string outputTopN(map<int,vector<string> > &rankedWords, int N, string fileName){  //function to output top N most frequent words from the rank map
	cout<<"IN OUTPUTTOPN"<<endl;
	int numOutput = 0;										 //must keep track because it may not be equal to the number of pairs in the map
	map<int, vector<string> >::reverse_iterator rIT;
	vector<string>::const_iterator lIT;

	string toOutput;
	bool inLoop=false;										 //indicates if the inner loop was broken
	for(rIT=rankedWords.rbegin(); rIT!=rankedWords.rend(); rIT++){  //backward because we want the higest value first
		for(lIT=rIT->second.begin(); lIT!=rIT->second.end(); lIT++){  //outputting the vector alphabetically
			toOutput.append(fileName);
			toOutput.append(",");
			toOutput.append(*lIT);
			toOutput.append(",");
			toOutput.append(i2s(rIT->first));
			toOutput.append("\n");
			numOutput++;
			if(numOutput>=N){
				inLoop=true;
				break;
			}
		}
		if(inLoop==true){
			break;
		}
	}
}
int s2i(string a){		//function to convert an int to a string
	std::string myString = a;
	int value = atoi(myString.c_str());
	return value;
}
void readFromDir(vector<string> &fileNs, string dirName){		//function to read file names from the directory
	//enumerating files in directory.   -- help from: http://stackoverflow.com/questions/612097/how-can-i-get-a-vector-of-files-in-a-directory-using-c-or-c
			DIR *dir;
		struct dirent *drnt;
			dir = opendir(dirName.c_str());
			drnt = readdir(dir);
			string filn;
		if(dir!=NULL){									//makes sure that there is a directory by that name
			while((drnt=readdir(dir))!=NULL){
				filn.append(dirName);
				filn.append(drnt->d_name);
				fileNs.push_back(filn);
			}
			closedir(dir);
		}
		else{
			cout<<"no directory by that name"<<endl;
		}
}
 void copyFiles(string SRC, string DEST){	//function to copy all files from one dir to another
	string toUse;
	char temp[100];
	toUse.append("cp ");
	toUse.append(SRC);
	toUse.append("* ");
	toUse.append(DEST);
	sprintf(temp, toUse.c_str());
	system((char *)temp);


}
 void URL2File(string urlFile, vector<string> &urls){		//function to gather list of URLS
	 ifstream URLnames;
	 URLnames.open(urlFile, ifstream::in);

	 string tIN;
	 while(URLnames){
		 URLnames>>tIN;
		 urls.push_back(tIN);
	 }
 }
 void downloadURL(string URL, string urlFN){		//function to download text of a website
	 string command;
	 char temp[100];
	 command.append("curl -o ");
	 command.append(urlFN);
	 command.append(" ");
	 command.append(URL);
	 sprintf(temp, command.c_str());
	 system((char *)temp);

 }
int main(int argc, char* argv[]){

		//Parallelization
	int rank,size;
	MPI_Status status;
	MPI_Init(&argc, &argv);

	MPI_Comm_rank(MPI_COMM_WORLD, &rank);  //determines ranks
	MPI_Comm_size(MPI_COMM_WORLD, &size);	//determines number of processors

	char arrBack[2000];
	char fileName[200];
	for(int i=0; i<20; i++){
		fileName[i]=' ';
	}
	int len;
			//Parsing Standard Input 
			//followed getopt example from http://www.ibm.com/developerworks/aix/library/au-unix-getopt.html 
			//and ftp://ftp.cs.uregina.ca/pub/class/330/IOandArgs/ioandargs.html 
		int numInputFiles = 0;
		int N=1;				//standard number top words to output is 1
		string dirName;
		int hasDir=0;
		vector<string> VfileNames;
		int useURL = 0;
		string URLfile;
		
		static char optstring[] = "n:?d:l:";
		int c;
		while((c = getopt(argc, argv, optstring)) != -1){
			//cout<<"in while"<<endl;
			switch(c){							//determining the input values
			case 'n':			//number of top words to output 
				N= s2i(optarg);
				break;
			case 'd':			//directory of multiple files
				hasDir=1;
				dirName = optarg;
				break;
			case 'l':
				useURL=1;
				URLfile = optarg;
				break;
			case '?':
				cout<<"Incorrect argument"<<endl;
				break;
			default:
				break;
			}
			if(hasDir!=1){		//gets file names if there is no directory
				while(optind < argc){			//getting files to parse
					VfileNames.push_back(argv[optind]);
					numInputFiles++;
					optind++;
				}
			}
		}

	if(rank==0){ 						//master 

		cout<<"in master rank"<<endl;
		
		double t1,t2;				//timing information
		t1=MPI_Wtime();

		if(hasDir==0 && useURL==0){ //takes just a file name for input
			map<string, int> allwords;
			map<int, vector<string> > rankedWords;
			ifstream infile;
			for(int i=0; i<VfileNames.size(); i++){
				infile.open(VfileNames[i]);
				readNcount(infile,allwords);
				rankWords(allwords,rankedwords);
				outputTopN(rankedwords,N,vfileNames[i]);

			}
		}
		else{			//has either a directory name or a set of URLS
			vector<string> fileNs;
			if(hasDir==1){					//store file names of directory to the vector
				readFromDir(fileNs,dirName);
			}
			else if(useURL==1){				//store URLS in the directory
				URL2File(URLfile, fileNs);
			
			}

			int recv=0;
			int toP=1;
			cout<<"size: "<<size<<endl;
			while(fileNs.empty()!=true){  //while there are still file names to be processed, send them to the processes 
				for(int i=0; i<fileNs.back().length(); i++){
					fileName[i] = fileNs.back()[i];
				}
				cout<<"sent to: "<<toP<<endl;
				MPI_Send((void *)fileName, 20, MPI_CHAR, toP, 0, MPI_COMM_WORLD);		//sends either the file name or URL to the process
				toP++; 
				for(int i=0; i<20; i++){
					fileName[i]=' ';
				}
				if(toP==size-1){	//all processors have been sent something, reset toP and recieve their response. output it
					toP=1;
					cout<<"all processors are busy"<<endl;
					for(int k=1; k<size; k++){ //won't receive from master process
						cout<<"in recieve"<<endl;
						//recv++;
						MPI_Recv(&arrBack, len, MPI_CHAR, k, 0, MPI_COMM_WORLD, &status);
						std::string str;
						str = arrBack;
						cout<<str;

					}
				}
				fileNs.pop_back();
			}
		}
		t2=MPI_Wtime();
		int elapsed = t2-t1;
		cout<<"elapsed time: "<<elapsed<<endl;

	}
	else{				//slave processes
		cout<<"inProcess: "<<rank<<endl;
		MPI_Recv(fileName, 20, MPI_CHAR, 0, 0, MPI_COMM_WORLD, &status);
		int i =0; 
		string FiN;
		while(fileName[i]!=' '){
			FiN[i]=fileName[i];
			i++;
		}
		
		if(hasDir==1){		//if we are processing from a directory name inptu
			copyFiles(dirName, "/tmp/ker212");
		}
		else if(useURL==1){  //if we are downloading the URLs
			vector<string> allURLS;
			URL2File(URLfile, allURLS);
			string toF;
			for(int i=0; i<allURLS.size(); i++){
				toF.append(allURLS[i]);				//store file output as the URL.txt
				toF.append(".txt");
				downloadURL(allURLS[i], toF);
			}
		}
		
		//creates file path for the ifstream to open
		string filePath;
		filePath.append("/tmp/ker212/");
		filePath.append(FiN);

		//opens file, creates maps for function passing
		ifstream inFile;
		inFile.open(filePath, ifstream::in);
		cout<<"opened file"<<rank<<endl;
		map<string, int> allwords;
		map<int,vector<string> > rankedWords;
		
		//counts and ranks the words
		readNcount(inFile,allwords);
		cout<<"read in file"<<rank<<endl;
		rankWords(allwords,rankedWords);
		cout<<"ranked words"<<rank<<endl;
		string toSendBack;

		//appends a char array to send back to the main process for output
		std::string FN = fileName;
		toSendBack.append(outputTopN(rankedWords,N, FN));   //builds a string of the top N words in the document
		toSendBack.append("\n");	
		cout<<"appeneded string"<<rank<<endl;
		for(int i=0; i<toSendBack.length(); i++){
			arrBack[i] = toSendBack[i];
		}
		cout<<"about to send"<<rank<<endl;
		MPI_Send((void *)arrBack, 200, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
		cout<<"sent to 0 "<<rank<<endl;

		system("exec rm -r /tmp/*");  //clear folder

	}



	MPI_Finalize();
	

	return 0;

}
