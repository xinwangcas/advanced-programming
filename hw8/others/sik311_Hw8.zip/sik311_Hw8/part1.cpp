// CSE411 Homework8- part1
// Author : Siddarth Yagnam Konuganti
//We must run this program as    $ ./a.out -n N filename
// This program prints out the N most frequent words in the file = filename.

#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include<stdlib.h>
#include<stdio.h>

using namespace std;

// created a class which keeps track of all the words encounterd and stores the frequency of the word in value
class WordCounter
{
public:
    int value;  // To store the frequency of the words
    int prints; // A value used to print, is 1 if printed else 0
    WordCounter() : value( 0 ) {}
    
    void operator++ (int) { value++; } //checks for the word. and increments the value once its encounterd
};

// This function takes the input of the wordconter pointer and retuns the value of the frequency of the wordin the current file.
ostream& operator<<(ostream& st, WordCounter& wc )
{
    return st << wc.value;
}

void calculate_wordOccurences(int,char*);   // Function declaration
// This function takes the input of n-> number of frequent words to be printed out and The filename

int main(int argc, char** argv)
{
    int words;           // Stores the value of N-> "number of frequent words" given at the command line
    char filename[100]; // Stores the Filename which we will work on. Also given in the command line
    char c;            // To find what options are set
    c = getopt(argc, argv, "n");
    
    if(argc<4)
    {
        cout<<"Enter Correct #Arguments"<<endl;
        cout<<" Correct way is :  a.out -n '#frequent words required' file1 file2 ..."<<endl;
        return 0;
    }
    
    // checks if the option n is set 
        if (c=='n')
        {
            words = atoi(argv[2]);// saves the value given to words. converts string to int using "atoi"
            for( int i=3;argv[i]!=NULL;i++)
            {
                cout<<endl;
                strcpy(filename, argv[i]); // copies the name of the filename given as an argument
                calculate_wordOccurences(words,filename); // calls the function to calculate the n most frequent words
                
            }
            
        }
        else
        {
            // outputs that the arguments are Incorrect or in out of order and tells them how to enter the arguments
            cout<<"Incorrect Arguments"<<endl<<" order : ./a.out -n N filename"<<endl;
            return 1;   // exits the program
        }
   cout<<endl<< " Program Existed Normaly "<<endl;  // prints out that the program exited normally
    
    return 2;
}

void calculate_wordOccurences(int words,char* file)
{
    
    cout<<"File : "<<file<<endl;
    map<string, WordCounter> counter;   // creating a map which stores the words and frequency for all words in the file
    
    int i,j,k;      // Intializing the loop variables
    
    ifstream input;  // Initialising the input which is a filepointer
    input.open(file); // opening the file to read the input
    
    if ( !input )  // checking if the we can open the file
    {
        cout << "Error in opening file\n";  //  if not we print an error message
        return;         // then return to the main program
    }
    
    string tok;    // Declaring a string to read each word of a file
    while ( true ) // Go for infinite loop
    {
        input >> tok;   //  copying first word to tok
        if ( input )    // checks if the input is valid
        {
            // Delete all the punctuations after the word, if you encounter a punctuation then delte the word from there except the '
            for(i=0;i<tok.length();i++)
            {
                if(tok[i]=='!'||tok[i]==','||tok[i]=='.'||tok[i]=='?'||tok[i]=='/'||tok[i]=='@'||tok[i]=='#'||tok[i]=='$'|| tok[i]=='%'||tok[i]=='&'||tok[i]=='*'||tok[i]=='|')
                {
                    tok = tok.substr(0,i);
                    break;
                }
            }
        
            // As we dont consider the upper/lower case just change everything to uppercase and then compare
            for(i =0;i<tok.length();i++)
            {
                tok[i] = toupper(tok[i]);
            }
        
            counter[ tok ]++;       //  send the word into the counter "map", so in the wordcounter the value will be incremented if it already came across it
        }
        else
        {
            break; // if its out of words or END of file. Then break the while loop
        }
    }
    
    // Initializing the values for the iterator to iterate through the whole map
    map<string, WordCounter,less<string> >::iterator it;    // it loops throught the whole map
    map<string, WordCounter,less<string> >::iterator it1;   //it1 holds the map index of the most frequent word in that interation till then
    
    for ( it  = counter.begin();it != counter.end();it++ )
    {
        (*it).second.prints = 0;        // change all the values of prints in the wordcounter to 0
    }
    i=0;    //  counts no: of iterations of the while loop, so as each iteration prints the word with high frequeny
    
    while(true)  // Infinite loop
    {
        // if we have printed the required number of words then just break the while loop and return to main program
        if(i==words)
        {
            break;
        }
        
        i++;        // increment i
        k=0;        // K will value of the words with highest count till then in the loop
        
        for ( it  = counter.begin();it != counter.end();it++ )  //Iterate through the whole map part
        {
            if((*it).second.prints == 0)    // Only check if the word is not yet printed
            {
                if(k<(*it).second.value)    // if value of K is less than the "value"(frequency) of the current word then add k to it
                {
                    it1 = it;       //  save the value of it in it1
                    k = (*it).second.value; // Set the new checking standard "K" to frequency of the current word
                }
                else if(k==(*it).second.value)  //else if both have the same values, then check for the alphabetic order of 2 words
                {
                    if((*it1).first.compare((*it).first)<0)
                    {
                        continue;   // if  the current iteration word is less than current "it1" standard then continue
                    }
                    else    // else change the standard to the current iteration word
                    {
                        it1 = it;
                        k = (*it).second.value;
                    }
                }
            }
        }
        
        // once done through the whole map, we found the new highest word and its count in it1, So print it
        cout << (*it1).first<< ", "<< (*it1).second<< endl;

        // As we printed it, we pdate the print variable of that wordcounter to 1
        (*it1).second.prints = 1;
        
        
    }
    input.close(); // closing the file
}
