#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <stdio.h>
#include<fcntl.h>
#include<string.h>
#include<stdlib.h>
#include<pwd.h>
#include<grp.h>
#include<time.h>
#include<dirent.h>
#include<sys/stat.h>
#include "mpi.h"

using namespace std;

void calculate_wordOccurences(int,int,char*); //A function which calculates the 'n' frequent numbers, with inputs rank,n,filename

// This is a class wordcounter, which is a second part for the map, It has the freauency of a particular word in value, another flag named "prints", which states whether the word is printed or not for the printing part, we can know more about that during the usage

class WordCounter
{
public:
    int value;  // To store the frequency of the words
    int prints; // A value used to print, is 1 if printed else 0
    WordCounter() : value( 0 ) {}
    
    void operator++ (int) { value++; }  //checks for the word. and increments the value once its encounterd
};

// This function takes the input of the wordconter pointer and retuns the value of the frequency of the wordin the current file.

ostream& operator<<(ostream& st, WordCounter& wc )
{
    return st << wc.value;
}


// Main function
int main (int argc, char** argv)
{
    MPI_Status s;   // For the use of parrallel programming
    double t1,t2;   // For counting the execution time
    
    int size=0, rank=0; // to know the rank and size of the process
    int i=0,j=0,x=0,y=0;    // loop variables used in the function
    int words=0,value_n=0;  //words saves the value of n, in the master process and value_n is the same value stored by the slave processes
    int tot_files_number=0; //calculates the total # files in a directory
    
    char filename[100],recvfile[1000];   //Filename stores the directory name and recv file stores the file to be processes by each slave process
    
    char c; // Uses to fing what options are set
    
    MPI_Init(&argc, &argv); //Initializing the MPI
    
    t1 = MPI_Wtime();   //Noting down the current time
    
    DIR *dir,*dir1;             // Directory variables used to traverse through the directory
    struct dirent *ent,*ent1;
    
    int option_n=0,option_d=0; //to know which options are set and which are not
    
    
    // Getopt retirns which options are set and switch lets us to set the values, if invalid options are set then exits program and sends an responce
    while ((c = getopt(argc, argv, "nd")) != -1)
    {
        switch (c)
        {
            case 'n' :
                option_n=1;
                break;
            case 'd':
                option_d = 1;
                break;
            default:
                printf("Invalid options are set\n");
                cout<<"correct ways are :"<<endl;
                cout<<endl<<"     mpirun nx-y -ssi rpi usysv part2 -nd '#frequent words required' directory"<<endl<<endl;
                MPI_Finalize();
                return 5;
                
        }
    }

    
    MPI_Comm_size(MPI_COMM_WORLD, &size);   // to know the size of the nodes
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);   // to know its own rank
    
    if(rank==0) //Master process
    {
        
        if((option_n==0||option_d==0)||argc!=4) // If both the options are not set or invalid arguments are given, tells how to run the program and exits
        {
            cout<<"Wrong number of arguments or options ";
            cout<<"correct ways are :"<<endl;
            cout<<endl<<"     mpirun nx-y -ssi rpi usysv part2 -nd '#frequent words required' directory"<<endl<<endl;
            
            MPI_Finalize();
            return 4;

        }
        else if(option_n==1&&option_d==1)   // Else notifies Both options are set and copies n in words and directory name in filename
        {
            cout<<"Both the Options Set, So allocating the processes for all the nodes "<<endl;
            words = atoi(argv[2]);
            cout<<words<<endl;
            strcpy(filename,argv[3]);
            
        }
        
        // The below function calculates the #files the directory has, just to know how many processes must be shared by the slaves
        //--------------------------------------------------------------------------------
        dir1 = opendir(filename);
        i=0;
        while((ent1 = readdir (dir1)) != NULL)
        {   if((strcmp(ent1->d_name,".")==0)||(strcmp(ent1->d_name,"..")==0))
        {
            continue;
        }
            i++;
        }
        cout<<"Total number of files are  in the directory are : "<<i<<endl;
        tot_files_number = i;
        closedir(dir1);
        //--------------------------------------------------------------------------------
        
        y=tot_files_number/size;    // Y tells us how many files are needed to be processed by each slave node
        x=tot_files_number-(y*size);    // Ex: there are 10 files and 4 nodes, each node must process 2 files and the remaining 2 files must be processed by the nodes 0,1. X tells this
        
        // Sends the value of total number of files and value(n) ie number of frequent words to be calculated in each file to all the slave processes
        for(i=0;i<size;i++)
        {
            MPI_Send ((void *)&tot_files_number, 1, MPI_INT, i, 0xACE5, MPI_COMM_WORLD);
            MPI_Send ((void *)&words, 1, MPI_INT, i, 0xACE5, MPI_COMM_WORLD);
        }
        
        // As this also processes some of the files, it also receives them
        
        MPI_Recv((void *)&tot_files_number, 1, MPI_INT,0, 0xACE5, MPI_COMM_WORLD, &s);
        MPI_Recv((void *)&value_n, 1, MPI_INT,0, 0xACE5, MPI_COMM_WORLD, &s);
        cout<<value_n<<endl;
        
        // Open the directory to read all files
        
        dir = opendir(filename);
        
        // Now send the filenames to be processed by the slave processes 
        for(i=0;i<tot_files_number;i++)
        {   
            char filename1[100];        //stores the filename of each process with the whole filepath
            
            strcpy(filename1,filename); //here copies the filepath till directory   filename1 = /proj/spear1/cse411
            
            strcat(filename1,"/");  //concatenates to go into the directory --> filename1 = /proj/spear1/cse411/
            
            if((ent = readdir (dir)) != NULL)   // ent is a direct object and reads each file till its null
            {
                while((strcmp(ent->d_name,".")==0)||(strcmp(ent->d_name,"..")==0))  // if the files are . or .. then continues 
                {
                    ent = readdir(dir);
                }
                strcat(filename1,ent->d_name);  // else stores the current file ie ent->d_name into the filename1. Ex if ent->d_name is "pg100.txt"--> filename1s = /proj/spear1/cse411/pg100.txt
            }
            
            MPI_Send ((void *)filename1,100, MPI_CHAR, i%size, 0xACE5, MPI_COMM_WORLD); //sends  to the process i%size, this way if there we are sending 10 files to 4 nodes(0,1,2,3,4),the files are sent in this fasion n0,n1,n2,n3,n0,n1,n2,n3,n0,n1
            
           
            
        }
        
        MPI_Recv((void *)recvfile, 100, MPI_CHAR, 0, 0xACE5, MPI_COMM_WORLD, &s);   // receive the first filename which is stored in recvfile
        
        calculate_wordOccurences(rank,value_n,recvfile);    // perform the calculation
        
        
        for(i=1;i<y;i++)    // As we may receive more extra files depending on the rank we are we receive from 1 to less than Y
        {
            MPI_Recv((void *)recvfile, 100, MPI_CHAR, 0, 0xACE5, MPI_COMM_WORLD, &s);
            
            calculate_wordOccurences(rank,value_n,recvfile);
        
        }
        
        //As we know after perfroming for "y =total_files/size" times , if the rank of the process is less than x = total_files - y; then it receives again
        if(rank<x)
        {
            MPI_Recv((void *)recvfile, 100, MPI_CHAR, 0, 0xACE5, MPI_COMM_WORLD, &s);   
            
            calculate_wordOccurences(rank,value_n,recvfile);
        
        }
        
        // Now recieve back the output from each process. We print in the order of the calculations done by each process by rank wise

        
        for(i=0;i<size;i++)     // for each rank 
        {   cout<<"Files processed by rank : "<<i<<endl;    //print that these are the files processed by the rank i 
            for(j=0;j<tot_files_number;j++)         // Now receive all the output sent by the slave node i
            {
                if(i==(j%size))
                {
                    MPI_Recv((void *)recvfile, 1000, MPI_CHAR,i, 0xACE5, MPI_COMM_WORLD, &s);   //store the output in the recvfile
                    cout<<recvfile<<endl;   //print the putput
                }
            }
        }
        
        t2 = MPI_Wtime();   // calculate the time after the whole master process is completed and substracting it with the start time gives the exection time
        printf("\nExecution time is %f sec\n",t2-t1);
        closedir(dir);
            
    }
    else    //Slave processes
    {   
        if(option_d!=1||option_n!=1||argc!=4)   // If the option_d or option_n or wrong #arguments are given then exit the program
        {
            MPI_Finalize();
            return 2;
        }
        else    // Else perform the same as the rank 0. Recive the total file number, words to printed and receive the files from the master process, process it and send the result back to the master process, just seeing the progrma U can understand whats going on.
        {
            MPI_Recv((void *)&tot_files_number, 1, MPI_INT,0, 0xACE5, MPI_COMM_WORLD, &s);
            MPI_Recv((void *)&value_n, 1, MPI_INT,0, 0xACE5, MPI_COMM_WORLD, &s);
            
            y = tot_files_number/size;
            x = tot_files_number-(y*size);
            
            MPI_Recv((void *)recvfile, 100, MPI_CHAR, 0, 0xACE5, MPI_COMM_WORLD, &s);
            
            calculate_wordOccurences(rank,value_n,recvfile);
            
            for(i=1;i<y;i++)
            {
                MPI_Recv((void *)recvfile, 100, MPI_CHAR, 0, 0xACE5, MPI_COMM_WORLD, &s);
                
                calculate_wordOccurences(rank,value_n,recvfile);
                
            }
            
            if(rank<x)
            {
                MPI_Recv((void *)recvfile, 100, MPI_CHAR, 0, 0xACE5, MPI_COMM_WORLD, &s);
                
                calculate_wordOccurences(rank,value_n,recvfile);
            }
            
        }
    }


    // Once everything is done exit the program normally
    
    MPI_Finalize();
    return 3;
}

void calculate_wordOccurences(int rank,int word,char* file)
{   char c[1000];   // To store the output
    ostringstream out;  //Creating an outstream to store the value of the output in a charecter c.
    map<string, WordCounter> counter; // creating a map which stores the words and frequency for all words in the file

    int i,j,k;   // Intializing the loop variables
    
    ifstream input; // Initialising the input which is a filepointer
    input.open(file);   // opening the file to read the input
    
    if ( !input )   // checking if the we can open the file
    {
        cout << "Error in opening file '"<<file<<"'  in rank :"<<rank<<endl;    //  if not we print an error message
        return;  // then return to the main program
    }   
    
    string tok; // Declaring a string to read each word of a file
    while ( true )  // Go for infinite loop

    {
        input >> tok;   //  copying first word to tok
        if ( input )    // checks if the input is valid
        {
            // Delete all the punctuations after the word, if you encounter a punctuation then delte the word from there except the '
            for(i=0;i<tok.length();i++)
            {
                if(tok[i]=='!'||tok[i]==','||tok[i]=='.'||tok[i]=='?'||tok[i]=='/'||tok[i]=='@'||tok[i]=='#'||tok[i]=='$'||tok[i]=='%'||tok[i]=='&'||tok[i]=='*'||tok[i]=='|')
                {
                    tok = tok.substr(0,i);
                    break;
                }
            }
            
            // As we dont consider the upper/lower case just change everything to uppercase and then compare
            for(i =0;i<tok.length();i++)
            {
                tok[i] = toupper(tok[i]);
            }
            
            counter[ tok ]++;    //  send the word into the counter "map", so in the wordcounter the value will be incremented if it already came across it
            
        }
        else
        {
            break;  // if its out of words or END of file. Then break the while loop
        }
    }
    
     // Initializing the values for the iterator to iterate through the whole map
    map <string, WordCounter, less<string> >::iterator it;  // it loops throught the whole map
    map <string, WordCounter, less<string> >::iterator it1; //it1 holds the map index of the most frequent word in that interation till then
    
    for ( it  = counter.begin();it != counter.end();it++ )
    {
        (*it).second.prints = 0;    // change all the values of prints in the wordcounter to 0
    }
    
    i=0;    //  counts no: of iterations of the while loop, so as each iteration prints the word with high frequeny
    
    while(true)
    {   if(i==word) //If enough frequent words are printed then exit
        {
        break;
        }
        i++;    // increment i
        k=0;    // K will value of the words with highest count till then in the loop
        
        for ( it  = counter.begin();it != counter.end();it++ )  //Iterate through the whole map part
        {
            if((*it).second.prints == 0)    // Only check if the word is not yet printed
            {
                if(k<(*it).second.value)    // if value of K is less than the "value"(frequency) of the current word then add k to it
                {   
                    it1 = it;   //  save the value of it in it1
                    k = (*it).second.value; // Set the new checking standard "K" to frequency of the current word

                }
                else if(k==(*it).second.value)  //else if both have the same values, then check for the alphabetic order of 2 words
                {
                    if((*it1).first.compare((*it).first)<0)
                    {
                        continue;   // if  the current iteration word is less than current "it1" standard then continue
                    }
                    else    // else change the standard to the current iteration word
                    {
                        it1 = it;
                        k = (*it).second.value;
                    }
                }
            }
        }
        // once done through the whole map, we found the new highest word and its count in it1, So store it in 'ostream' object
        out <<rank<<" "<<file<<" : "<< (*it1).first<< ", "<< (*it1).second<< endl;
        (*it1).second.prints = 1;
        
    }
    
    strcpy(c,out.str().c_str());    // The ouput is stored in the charecter array array c
    input.close();                  //close the input file
    
     MPI_Send ((void *)c,1000, MPI_CHAR,0, 0xACE5, MPI_COMM_WORLD); //Send the output data to the Master process
    
        return; // return the main process.
}













