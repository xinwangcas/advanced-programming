#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <stdio.h>
#include<fcntl.h>
#include<string.h>
#include<stdlib.h>
#include<pwd.h>
#include<grp.h>
#include<time.h>
#include<dirent.h>
#include<sys/stat.h>
#include "mpi.h"

void copyfile(char*);   // Afunction which takes the input of the filename and copies it to /tmp/sik311


//Main function
int main (int argc, char** argv)
{
    MPI_Status s;   // For the use of parrallel programming
    double t1,t2;   // For counting the execution time

    int size=0, rank=0,i=0,j=0; // to know the rank and size of the process and loop variables

    int tot_files_number=0,x=0,y=0; //calculates the total # files in a directory
    
    char filename[100],recvfile[100];   //Filename stores the directory name and recv file stores the file to be processes by each slave process
    
    char c; // Uses to fing what options are set
    
    MPI_Init(&argc, &argv); //Initializing the MPI
    
    t1 = MPI_Wtime();   //Noting down the current time
    
    DIR *dir,*dir1; 
    
    struct dirent *ent,*ent1;   // Directory variables used to traverse through the directory

    
    int option_d=0; //to know if option d is set or not

    // Getopt retirns which options are set and switch lets us to set the values, if invalid options are set then exits program and sends an responce
    while ((c = getopt(argc, argv, "d")) != -1)
    {
        switch (c)
        {
            case 'd':
                option_d = 1;
                break;
            default:
                printf("Invalid options are set\n");
                printf("Wrong number of arguments or options. Correct way is \n");
                
                
                printf("\n     mpirun nx-y -ssi rpi usysv part3 -d directory\n\n");
                

                MPI_Finalize();
        }
    }
    
    MPI_Comm_size(MPI_COMM_WORLD, &size);   // to know the size of the nodes    
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);   // to know its own rank


    if(rank==0) //Master process
    {
        if(option_d!=1&&argc!=3)    // If  the option is not set or invalid arguments are given, tells how to run the program and exits
        {
           printf("Wrong number of arguments or options. Correct way is \n");
        
            
            printf("\n     mpirun nx-y -ssi rpi usysv part3 -d directory\n\n");
            
            MPI_Finalize();
            return 1;

            
        }
        else    // Else notifies Both options are set and copies n in words and directory name in filename
        {
            strcpy(filename,argv[2]);
        }
        
        // The below function calculates the #files the directory has, just to know how many processes must be shared by the slaves
        //--------------------------------------------------------------------------------
        dir1 = opendir(filename);
        i=0;
        while((ent1 = readdir (dir1)) != NULL)
        {   if((strcmp(ent1->d_name,".")==0)||(strcmp(ent1->d_name,"..")==0))
        {
            continue;
        }
            i++;
        }
        //cout<<"Total number of files are  in the directory are : "<<i<<endl;
        tot_files_number = i;
        closedir(dir1);
        //--------------------------------------------------------------------------------
        
        
        // Sends the value of total number of files to all the slave processes

        for(i=0;i<size;i++)
        {
            MPI_Send ((void *)&tot_files_number, 1, MPI_INT, i, 0xACE5, MPI_COMM_WORLD);
        }
        
         // As this also processes some of the files, it also receives them
        MPI_Recv((void *)&tot_files_number, 1, MPI_INT,0, 0xACE5, MPI_COMM_WORLD, &s);
        
         // Open the directory to read all files
        dir = opendir(filename);
       
        //Send all the files in the directory to all the nodes, So they copy all the files to their correspondong /tmp/sik311.
        for(i=0;i<tot_files_number;i++)
        {
            char filename1[100];
            
            strcpy(filename1,filename);
            
            strcat(filename1,"/");
            
            if((ent = readdir (dir)) != NULL)
            {
                while((strcmp(ent->d_name,".")==0)||(strcmp(ent->d_name,"..")==0))
                {
                    ent = readdir(dir);
                }
                strcat(filename1,ent->d_name);
            }
            
            for(j=0;j<size;j++)
            {
                MPI_Send ((void *)filename1,100, MPI_CHAR,j, 0xACE5, MPI_COMM_WORLD);
            }
            
        }
        
        // Receives all the files in the directory
        for(i=0;i<tot_files_number;i++)
        {
            MPI_Recv((void *)recvfile, 100, MPI_CHAR, 0, 0xACE5, MPI_COMM_WORLD, &s);
        
            copyfile(recvfile); //perform the copy operation
        }
        
        
        // print that all are copied without any errors and then calculate the execution time
        printf("\nCopied all files to the /tmp/sik311 folder in all nodes\n");
        t2 = MPI_Wtime();
        printf("Execution time is %f sec\n\n",t2-t1);
        closedir(dir);
    }
    
    else    //Slave Process
    {
        if(option_d!=1&&argc!=3)    // If no option_d is set or argumaent is !=3 then exit the process
        {
            MPI_Finalize();
            return 2;
        }
        //else recieve all the files and copy them to /tmp/sik311
        MPI_Recv((void *)&tot_files_number, 1, MPI_INT,0, 0xACE5, MPI_COMM_WORLD, &s);
        
        for(i=0;i<tot_files_number;i++)
        {
            MPI_Recv((void *)recvfile, 100, MPI_CHAR, 0, 0xACE5, MPI_COMM_WORLD, &s);
            
            copyfile(recvfile);
        }

        
    }
    
    //if everything goes fine , exit the program succesfully
    MPI_Finalize();
    return 3;
}



// Function that takes input of the file and copied it to the /tmp/sik311 directory
void copyfile(char* file)
{   char c[100];
    
    sprintf(c,"cp %s /tmp/sik311",file);    //create a string with the cp command
    
    
    // Using the systemcall copy the file
    system(c);
    
    //printf("%s\n",file);
    return;
}

















