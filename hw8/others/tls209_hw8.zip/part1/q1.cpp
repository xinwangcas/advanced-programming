/**
 * Homework 8 (Part 1)
 * by Todd Suess
 *
 * Reads a text file and determines the N most frequently occurring words.
 */
#include <iostream>
#include <fstream>
#include <libgen.h>
#include <stdio.h>
#include <map>
#include <vector>
using namespace std;

// Number of words to determine
int n_wrds = -1;

// Word map (word => usage)
map<string,int> words;

// Ordered word map (usage => {word})
map< int, vector<string> > ordered;



/**
 * Outputs an error message to the err stream and terminates the program.
 * @param exe the EXE name (may contain path)
 * @param msg the error message
 */
void error (char *exe, char *msg) {
	cerr << basename(exe) << ": " << msg << endl;
	exit(-1);
}

/**
 * Counts a series of most frequently occurring words (counts value in n_wrds)
 * from a given file and outputs the words to the stdout stream.
 * @param f the absolute/relative path and filename of the file to read
 */
void count_words (char *f) {
	ifstream fin;
	fin.open(f);
	string tmp = "";
	char c;
	int max = 0;
	words.clear();
	ordered.clear();

	// Read words into word map
	while (fin.good()) {
		tmp = "";
		c = fin.get();
		while (fin.good() && !isalpha(c)) {
			c = fin.get();
		}
		while (fin.good() && isalpha(c)) {
			tmp += c;
			c = fin.get();
		}

		for(unsigned int j=0;j<tmp.length();j++) {
			// Convert to lower-case
			if (tmp[j] >= 'A' && tmp[j] <= 'Z')
				tmp[j] += 'a'-'A';
		}
		if (tmp.length() > 0) {
			if (words.find(tmp) != words.end()) {
				words[tmp]++;
				if (words[tmp] > max)
					max = words[tmp];
			} else words[tmp] = 1;
		}
	}
	fin.close();

	// Sort into ordered map
	map<string,int>::iterator it;

	for (it=words.begin();it!=words.end();it++){
		ordered[max-(it->second)].push_back(it->first);
	}
	int j=0,k;
	
	// Strings stored in vectors in the event that two or more words contain the same usage
	map<int, vector<string> >::iterator iter;
	iter=ordered.begin();
	while(j<n_wrds && iter!=ordered.end()) {
		k=j;
		while(j<n_wrds&&(unsigned)j-k<iter->second.size()){
			cout << f << "," << iter->second[j-k] << "," << max-(iter->first)<< endl;
			j++;
		}
		iter++;
	}
}

/**
 * Main method
 */
int main (int argc, char* argv[]) {	
	int st;
	while ((st = getopt(argc, argv, "n:")) != -1) {
		switch (st) {
			case 'n':
				n_wrds = atoi(optarg);
				break;
			default:
				error(argv[0], "Unknown parameter specified");
				break;
		}
	}
	if (optind >= argc)
		error(argv[0], "File parameter expected");
	if (n_wrds < 0)
		error(argv[0], "Word parameter (-n) required");
	while (optind < argc)	
		count_words(argv[optind++]);
	return 0;
}
