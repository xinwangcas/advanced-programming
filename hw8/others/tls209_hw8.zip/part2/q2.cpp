/**
 * Homework 8 (Part 2)
 * by Todd Suess
 *
 * Reads a text file and determines the N most frequently occurring words.  Oh,
 * did I mention it uses MPI?  Yeah... it uses MPI and parallelizes the process
 * across a series of machines (preferably with the same specs).
 */
#include <iostream>
#include <fstream>
#include <libgen.h>
#include <stdio.h>
#include <map>
#include <vector>
#include <dirent.h>
#include <sys/stat.h>
#include "mpi.h"

#define MASTER 0
#define FROM_MASTER 1
#define FROM_WORKER 2

using namespace std;

// Process ID (0 is master, >0 is a slave)
int proc;

// Number of processes created
int nprocs;

// Number of words
int n_wrds = -1;

// Word map
map<string,int> words;

// Ordered word map
map< int, vector<string> > ordered;



/**
 * Outputs an error message to the err stream and terminates the program.
 * @param exe the EXE name (may contain path)
 * @param msg the error message
 */
void error (char *exe, char *msg) {
	cerr << basename(exe) << ": " << msg << endl;
	exit(-1);
}

/**
 * Sends an integer to a specific process via MPI.
 * @param rank the process to which data is sent
 * @param data the integer to send
 */
void send_int (int rank, int data) {
	int mtype = (proc == 0 ? FROM_MASTER : FROM_WORKER);
	MPI_Send(&data, 1, MPI_INT, rank, mtype, MPI_COMM_WORLD);
}

/**
 * Blocks to receive an integer from a process.
 * @param rank the process that sent the data
 * @param the sending process's tag (FROM_WORKER or FROM_MASTER)
 * @return the integer data
 */
int recv_int (int rank, int from) {
	MPI_Status status;
	int data = 0;
	MPI_Recv(&data, 1, MPI_INT, rank, from, MPI_COMM_WORLD, &status);
	return data;
}

/**
 * Sends a string (char*) to a specific process via MPI.
 * @param rank the process to which data is sent
 * @param data the string to send
 */
void send_pchar (int rank, char *str) {
	int mtype = (proc == 0 ? FROM_MASTER : FROM_WORKER);
	int len = strlen(str);
	send_int(rank, len);
	MPI_Send(str, len, MPI_BYTE, rank, mtype, MPI_COMM_WORLD);
}

/**
 * Blocks to receive a string from a process.
 * @param rank the process that sent the data
 * @param the sending process's tag (FROM_WORKER or FROM_MASTER)
 * @return the string
 */
 char* recv_pchar (int rank, int from) {
	MPI_Status status;
	int len = recv_int(rank, from);
	char *str = new char[len+1];
	MPI_Recv(str, len, MPI_BYTE, rank, from, MPI_COMM_WORLD, &status);
	str[len] = '\0';
	return str;
}

/**
 * Sends a cstring to a specific process via MPI.
 * @param rank the process to which data is sent
 * @param data the cstring to send
 */
void send_str (int rank, string &str) {
	char *tmp = new char[str.length()+1];
	strcpy(tmp,str.c_str());
	send_pchar(rank, tmp);
	delete[] tmp;
}

/**
 * Blocks to receive a cstring from a process.
 * @param rank the process that sent the data
 * @param the sending process's tag (FROM_WORKER or FROM_MASTER)
 * @return the cstring
 */
string& recv_str (int rank, int from) {
	string *str = new string();
	char *tmp = recv_pchar(rank, from);
	str->append(tmp);
	delete[] tmp;
	return *str;
}

/**
 * Counts a series of most frequently occurring words (counts value in n_wrds)
 * from a given file and outputs the words to the master process via MPI.
 * @param f the absolute/relative path and filename of the file to read
 * @param fid the file ID (corresponding to file in table of master process)
 */
void count_words (string f, int fid) {
	ifstream fin;
	fin.open(f.c_str());
	string tmp = "";
	char c;
	int max = 0;
	words.clear();
	ordered.clear();
	
	while (fin.good()) {
		tmp = "";
		c = fin.get();
		while (fin.good() && !isalpha(c)) {
			c = fin.get();
		}
		while (fin.good() && isalpha(c)) {
			tmp += c;
			c = fin.get();
		}
		
		for(unsigned int j=0;j<tmp.length();j++) {
			// Convert to lower-case
			if (tmp[j] >= 'A' && tmp[j] <= 'Z')
				tmp[j] += 'a'-'A';
		}
		if (tmp.length() > 0) {
			if (words.find(tmp) != words.end()) {
				words[tmp]++;
				if (words[tmp] > max)
					max = words[tmp];
			} else words[tmp] = 1;
		}
	}
	fin.close();
	map<string,int>::iterator it;
	for (it=words.begin();it!=words.end();it++){
		ordered[max-(it->second)].push_back(it->first);
	}
	int j=0,k;
	map<int, vector<string> >::iterator iter;
	iter=ordered.begin();

	// Send out the count...
	send_int(MASTER, words.size() < (unsigned)n_wrds ? words.size() : n_wrds);
	
	// File
	send_int(MASTER, fid);
	while(j<n_wrds && iter!=ordered.end()) {
		k=j;
		while(j<n_wrds&&(unsigned)j-k<iter->second.size()){
			// Word
			send_str(MASTER, iter->second[j-k]);
			// Usage
			send_int(MASTER, max-(iter->first));

			j++;
		}
		iter++;
	}
}

/**
 * Code executed by the master process to dispatch files to all slave 
 * processes.  Essentially takes all arguments and distributes files to slave
 * processes to count and return, then outputs the results from each slave.
 * @param argc the argument count
 * @param argv the argument values
 */
void run_master (int argc, char* argv[]) {
	char *dir = NULL;
	if (nprocs < 2)		// Don't do anything if there master has no slaves (you know, like ancient Egypt)
		error(argv[0], "Master process has no workers");
	int st;
	while ((st = getopt(argc, argv, "n:d:")) != -1) {
		switch (st) {
			case 'n':
				n_wrds = atoi(optarg);
				break;
			case 'd':
				dir = optarg;
				break;
			default:
				error(argv[0], "Unknown parameter specified");
				break;
		}
	}
	if (n_wrds < 0)
		error(argv[0], "Word parameter (-n) required");
	if (dir == NULL)
		error(argv[0], "Directory parameter (-d) required");
	if (optind < argc)
		error(argv[0], "Unexpected parameters given");
	
	struct dirent *dp;
	struct stat fst;
	map<int, string> files;
	string tmp;
	
	DIR *d = opendir(dir);
	
	if (d == NULL) {
		cout << "Cannot open directory \"" << dir << "\"\n";
		for (int j=1;j<nprocs;j++)
			send_int(j,0);
		return;
	}

	while (dp = readdir(d)) {
		tmp = dir;
		if (dir[strlen(dir)-1] != '/')
			tmp += "/";
		tmp += dp->d_name;
		stat(tmp.c_str(), &fst);
		if (S_ISREG(fst.st_mode)) {
			files[files.size()] = tmp;
		}
	}
	
	closedir(d);
	if (files.size() == 0) {
		for (int j=1;j<nprocs;j++){
			send_int(j,0);
		}
		return;
	}
	
	// Dispatch
	unsigned int disp = 0, recv = 0;
	int tmp_id, usage;
	string word;
	map<int, string>::iterator f_iter = files.begin();
	
	// 2 Scenarios (files <= procs) and (procs < files)
	
	if (files.size() <= (unsigned)nprocs-1) {
		// Dispatch
		for (int j=1;j<nprocs;j++) {
			if (f_iter != files.end()) {
				send_int(j, 1);
				send_int(j, n_wrds);
				send_int(j, f_iter->first);
				send_str(j, f_iter->second);
				f_iter++;
				disp++;
			} else {
				send_int(j, 0);
			}
		}
		
		// Receive
		for (int j=1;j<nprocs && recv < disp;j++,recv++) {
			// # of files processed
			recv_int(j, FROM_WORKER);	// Sends 1 since we went it only one file
			
			// Number of words
			n_wrds = recv_int(j, FROM_WORKER);
		
			// File ID
			tmp_id = recv_int(j, FROM_WORKER);
			for (int k=0;k<n_wrds;k++){
				// Word
				word = recv_str(j, FROM_WORKER);
				// Usage
				usage = recv_int(j, FROM_WORKER);
				
				cout << files[tmp_id] << "," << word << "," << usage << "\n";
			}
		}
	} else {
		// Calculate number of files to send to each slave process
		int per_proc = files.size() / (nprocs-1),				// Typical per process load
			lst_proc = nprocs - (files.size() % (nprocs-1)),	// Load for last process (if uneven)
			f_dsp;
		
		// Dispatch
		for (int j=1;j<nprocs;j++) {
			// If last process, dispatch "extra" in last process count (lst_proc)
			f_dsp = j >= lst_proc ? per_proc+1 : per_proc;
			send_int(j, f_dsp);
			
			send_int(j, n_wrds);
			
			for (int k=0;k<f_dsp;k++) {
				send_int(j, f_iter->first);
				send_str(j, f_iter->second);
				f_iter++;
			}
		}
		
		// Receive
		for (int j=1;j<nprocs;j++) {
			// Have the worker tell us how many files to send us...
			f_dsp = recv_int(j, FROM_WORKER);
			
			for (int f=0;f<f_dsp;f++) {
				// Number of words
				n_wrds = recv_int(j, FROM_WORKER);
		
				// File ID
				tmp_id = recv_int(j, FROM_WORKER);
				for (int k=0;k<n_wrds;k++){
					// Word
					word = recv_str(j, FROM_WORKER);
					// Usage
					usage = recv_int(j, FROM_WORKER);
					
					cout << files[tmp_id] << "," << word << "," << usage << "\n";
				}
			}
		}
	}
}

/**
 * Runs the code for the slave process which entails reading a series of files
 * and returning their results to the master process via MPI.
 */
void run_slave () {
	// File ID (corresponding to file table in master process)
	int file_id;

	// Number of files
	int fc = recv_int(MASTER, FROM_MASTER);
	
	if (fc == 0) return;
	
	// Number of words
	n_wrds = recv_int(MASTER, FROM_MASTER);
		
	map<int, string> files;
	string fn;
	
	for (int j=0;j<fc;j++) {
		// File ID
		file_id = recv_int(MASTER, FROM_MASTER);
		// Filename
		fn = recv_str(MASTER, FROM_MASTER);
		files[file_id] = fn;
	}
	
	// Send files processed to MASTER
	send_int(MASTER, files.size());
	map<int, string>::iterator f_iter;
	for (f_iter = files.begin(); f_iter != files.end(); f_iter++)
		count_words(f_iter->second, f_iter->first);
}

/**
 * Main method
 */
int main (int argc, char *argv[]) {
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &proc);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
	if (proc == MASTER) {
		double t1, t2;
		t1 = MPI_Wtime();
		run_master(argc, argv);
		t2 = MPI_Wtime();
		cout << "Time Elapsed: " << t2-t1 << " sec\n";
	} else if (proc > MASTER) {
		run_slave();
		
		MPI_Finalize();
	}
	return 0;
}
