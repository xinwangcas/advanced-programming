/**
 * Homework 8 (Part 3)
 * by Todd Suess
 *
 * Reads a directory containing files and calls all slave processes to copy
 * all files from a user-specified directory to each slave's server's temp
 * directory.
 */
#include <iostream>
#include <fstream>
#include <libgen.h>
#include <dirent.h>
#include <sys/stat.h>
#include "mpi.h"
using namespace std;

#define MASTER 0
#define FROM_MASTER 1
#define FROM_WORKER 2
#define UNIX_TMP "/tmp/"
#define USERNAME "tls209"

// Process rank (0 = master)
int proc;

// Number of processes running
int nprocs;

// Source directory to read
char *srcdir = NULL;



/**
 * Outputs an error message to the err stream and terminates the program.
 * @param exe the EXE name (may contain path)
 * @param msg the error message
 */
void error (char *exe, char *msg) {
	cerr << basename(exe) << ": " << msg << endl;
	exit(-1);
}

/**
 * Sends an integer to a specific process via MPI.
 * @param rank the process to which data is sent
 * @param data the integer to send
 */
void send_int (int rank, int data) {
	int mtype = (proc == 0 ? FROM_MASTER : FROM_WORKER);
	MPI_Send(&data, 1, MPI_INT, rank, mtype, MPI_COMM_WORLD);
}

/**
 * Blocks to receive an integer from a process.
 * @param rank the process that sent the data
 * @param the sending process's tag (FROM_WORKER or FROM_MASTER)
 * @return the integer data
 */
int recv_int (int rank, int from) {
	MPI_Status status;
	int data = 0;
	MPI_Recv(&data, 1, MPI_INT, rank, from, MPI_COMM_WORLD, &status);
	return data;
}

/**
 * Sends a string (char*) to a specific process via MPI.
 * @param rank the process to which data is sent
 * @param data the string to send
 */
void send_pchar (int rank, char *str) {
	int mtype = (proc == 0 ? FROM_MASTER : FROM_WORKER);
	int len = strlen(str);
	send_int(rank, len);
	MPI_Send(str, len, MPI_BYTE, rank, mtype, MPI_COMM_WORLD);
}

/**
 * Blocks to receive a string from a process.
 * @param rank the process that sent the data
 * @param the sending process's tag (FROM_WORKER or FROM_MASTER)
 * @return the string
 */
 char* recv_pchar (int rank, int from) {
	MPI_Status status;
	int len = recv_int(rank, from);
	char *str = new char[len+1];
	MPI_Recv(str, len, MPI_BYTE, rank, from, MPI_COMM_WORLD, &status);
	str[len] = '\0';
	return str;
}

/**
 * Sends a cstring to a specific process via MPI.
 * @param rank the process to which data is sent
 * @param data the cstring to send
 */
void send_str (int rank, string &str) {
	char *tmp = new char[str.length()+1];
	strcpy(tmp,str.c_str());
	send_pchar(rank, tmp);
	delete[] tmp;
}

/**
 * Blocks to receive a cstring from a process.
 * @param rank the process that sent the data
 * @param the sending process's tag (FROM_WORKER or FROM_MASTER)
 * @return the cstring
 */
string& recv_str (int rank, int from) {
	string *str = new string();
	char *tmp = recv_pchar(rank, from);
	str->append(tmp);
	delete[] tmp;
	return *str;
}

/**
 * Copies all files from a directory (specified in `srcdir`) to the user's
 * temp directory under "/tmp/".
 */
void copydir () {
	struct dirent *dp;
	struct stat fst;
	string tmp;
	ifstream fin;
	ofstream fout;

	DIR *d = opendir(srcdir);
	while (dp = readdir(d)) {
		tmp = "";
		tmp.append(srcdir);
		if (srcdir[strlen(srcdir)-1] != '/')
			tmp += '/';
		tmp += dp->d_name;
		stat(tmp.c_str(), &fst);
		if (S_ISREG(fst.st_mode)) {
			fin.open(tmp.c_str());
			tmp = UNIX_TMP;
			tmp += USERNAME;
			tmp += "/";

			stat(tmp.c_str(), &fst);
			if (!S_ISDIR(fst.st_mode))
				mkdir(tmp.c_str(), 0777);

			tmp += dp->d_name;
			fout.open(tmp.c_str());

			fout << fin.rdbuf();

			fout.close();
			fin.close();
		}
	}
	closedir(d);
	cout << "Proc (" << proc << ") files copied.\n";
}

/**
 * Executes the code in the master process which distributes a single directory
 * to all slave processes to copy files from the first level to each process's
 * server's respective temp directory.
 * @param argc the argument count from main
 * @param argv the arguments from main
 */
void run_master (int argc, char *argv[]) {
	int st;
	while ((st = getopt(argc, argv, "d:")) != EOF) {
		switch (st) {
			case 'd':
				srcdir = optarg;
				break;
			default:
				error(argv[0], "Unknown parameter given");
				break;
		}
	}
	if (srcdir == NULL)
		error(argv[0], "Directory parameter (-d) required");
	copydir();
	for (int j=1;j<nprocs;j++){
		send_pchar(j, srcdir);
	}
}

/**
 * Runs the code for the slave process which entails receiving the directory
 * to copy and performing a single-level copy to the temp directory.
 */
void run_slave () {
	srcdir = recv_pchar(MASTER, FROM_MASTER);
	copydir();
}

/**
 * Main method
 */
int main (int argc, char *argv[]) {
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &proc);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);

	if (proc == MASTER) {
		run_master(argc, argv);
	} else if (proc > MASTER) {
		run_slave();
		MPI_Finalize();
	}
}
