/**
 * Homework 8 (Part 4)
 * by Todd Suess
 *
 * Reads a text file containing URLs, downloads the files at those URLs, and
 * counts the words to determine the N most frequently occurring words, then
 * parallelizes the processes to return the results for separate files.
 */
#include <iostream>
#include <fstream>
#include <libgen.h>
#include <stdio.h>
#include <map>
#include <vector>
#include "mpi.h"

#define MASTER 0
#define FROM_MASTER 1
#define FROM_WORKER 2
#define DL_CMD "wget -q -P \"/tmp/tls209/\" "
#define TMP_DIR "/tmp/tls209/"

using namespace std;

// Process ID (0 is master, >0 is a slave)
int proc;

// Number of processes created
int nprocs;

// Number of words
int n_wrds = -1;

// Word map
map<string,int> words;

// Ordered word map
map< int, vector<string> > ordered;




/**
 * Outputs an error message to the err stream and terminates the program.
 * @param exe the EXE name (may contain path)
 * @param msg the error message
 */
void error (char *exe, char *msg) {
	cerr << basename(exe) << ": " << msg << endl;
	exit(-1);
}

/**
 * Sends an integer to a specific process via MPI.
 * @param rank the process to which data is sent
 * @param data the integer to send
 */
void send_int (int rank, int data) {
	int mtype = (proc == 0 ? FROM_MASTER : FROM_WORKER);
	MPI_Send(&data, 1, MPI_INT, rank, mtype, MPI_COMM_WORLD);
}

/**
 * Blocks to receive an integer from a process.
 * @param rank the process that sent the data
 * @param the sending process's tag (FROM_WORKER or FROM_MASTER)
 * @return the integer data
 */
int recv_int (int rank, int from) {
	MPI_Status status;
	int data = 0;
	MPI_Recv(&data, 1, MPI_INT, rank, from, MPI_COMM_WORLD, &status);
	return data;
}

/**
 * Sends a string (char*) to a specific process via MPI.
 * @param rank the process to which data is sent
 * @param data the string to send
 */
void send_pchar (int rank, char *str) {
	int mtype = (proc == 0 ? FROM_MASTER : FROM_WORKER);
	int len = strlen(str);
	send_int(rank, len);
	MPI_Send(str, len, MPI_BYTE, rank, mtype, MPI_COMM_WORLD);
}

/**
 * Blocks to receive a string from a process.
 * @param rank the process that sent the data
 * @param the sending process's tag (FROM_WORKER or FROM_MASTER)
 * @return the string
 */
 char* recv_pchar (int rank, int from) {
	MPI_Status status;
	int len = recv_int(rank, from);
	char *str = new char[len+1];
	MPI_Recv(str, len, MPI_BYTE, rank, from, MPI_COMM_WORLD, &status);
	str[len] = '\0';
	return str;
}

/**
 * Sends a cstring to a specific process via MPI.
 * @param rank the process to which data is sent
 * @param data the cstring to send
 */
void send_str (int rank, string &str) {
	char *tmp = new char[str.length()+1];
	strcpy(tmp,str.c_str());
	send_pchar(rank, tmp);
	delete[] tmp;
}

/**
 * Blocks to receive a cstring from a process.
 * @param rank the process that sent the data
 * @param the sending process's tag (FROM_WORKER or FROM_MASTER)
 * @return the cstring
 */
string& recv_str (int rank, int from) {
	string *str = new string();
	char *tmp = recv_pchar(rank, from);
	str->append(tmp);
	delete[] tmp;
	return *str;
}

/**
 * Counts a series of most frequently occurring words (counts value in n_wrds)
 * from a given file and outputs the words to the master process via MPI.
 * @param f the URL of the filename to download and read
 * @param fid the file ID (corresponding to URL in table of master process)
 */
void count_words (string f, int fid) {
	string tmp;
	
	tmp = DL_CMD;
	tmp += "\"";
	tmp += f;
	tmp += "\"";
	
	// If system call fails, return no words
	if (system(tmp.c_str())) {
		send_int(MASTER, 0);
		return;
	}
	
	// Adjust URL to make it a filename
	tmp = TMP_DIR;
	char *tmpf = new char[f.length()+1];
	strcpy(tmpf, f.c_str());
	tmp += basename(tmpf);
	delete[] tmpf;
	
	ifstream fin;
	fin.open(tmp.c_str());
	
	char c;
	int max = 0;
	words.clear();
	ordered.clear();
	
	while (fin.good()) {
		tmp = "";
		c = fin.get();
		while (fin.good() && !isalpha(c)) {
			c = fin.get();
		}
		while (fin.good() && isalpha(c)) {
			tmp += c;
			c = fin.get();
		}
		
		for(unsigned int j=0;j<tmp.length();j++) {
			// Convert to lower-case
			if (tmp[j] >= 'A' && tmp[j] <= 'Z')
				tmp[j] += 'a'-'A';
		}
		if (tmp.length() > 0) {
			if (words.find(tmp) != words.end()) {
				words[tmp]++;
				if (words[tmp] > max)
					max = words[tmp];
			} else words[tmp] = 1;
		}
	}
	fin.close();
	
	unlink(tmp.c_str());
	map<string,int>::iterator it;
	for (it=words.begin();it!=words.end();it++){
		ordered[max-(it->second)].push_back(it->first);
	}
	int j=0,k;
	map<int, vector<string> >::iterator iter;
	iter=ordered.begin();

	// Send out the count...
	send_int(MASTER, words.size() < (unsigned)n_wrds ? words.size() : n_wrds);
	
	// File
	send_int(MASTER, fid);
	while(j<n_wrds && iter!=ordered.end()) {
		k=j;
		while(j<n_wrds&&(unsigned)j-k<iter->second.size()){
			// Word
			send_str(MASTER, iter->second[j-k]);
			// Usage
			send_int(MASTER, max-(iter->first));

			j++;
		}
		iter++;
	}
}

/**
 * Code executed by the master process to dispatch files to all slave 
 * processes.  Essentially takes all arguments and distributes URLs to slave
 * processes to download, count, and return, then outputs the results from each
 * slave.
 * @param argc the argument count
 * @param argv the argument values
 */
void run_master (int argc, char* argv[]) {
	char *urlf = NULL;
	if (nprocs < 2)		// Don't do anything if there master has no slaves (you know, like ancient Egypt)
		error(argv[0], "Master process has no workers");
	int st;
	while ((st = getopt(argc, argv, "n:l:")) != -1) {
		switch (st) {
			case 'n':
				n_wrds = atoi(optarg);
				break;
			case 'l':
				urlf = optarg;
				break;
			default:
				error(argv[0], "Unknown parameter specified");
				break;
		}
	}
	if (n_wrds < 0)
		error(argv[0], "Word parameter (-n) required");
	if (urlf == NULL)
		error(argv[0], "URL file parameter (-l) required");
	if (optind < argc)
		error(argv[0], "Unexpected parameters given");

	map<int, string> files;
	string tmp;
	char tmp_url[1025];	// I doubt a URL is typically that long anyway
	
	ifstream fin;
	fin.open(urlf);
	while (fin.good()) {
		fin.getline(tmp_url, 1025);
		tmp = tmp_url;	// Convert it to a cstring...
		files[files.size()] = tmp;
	}
	
	
	if (files.size() == 0) {
		for (int j=1;j<nprocs;j++){
			send_int(j,0);
		}
		return;
	}

	// Dispatch
	unsigned int disp = 0, recv = 0;
	int tmp_id, usage;
	string word;
	map<int, string>::iterator f_iter = files.begin();
	
	// 2 Scenarios (files <= procs) and (procs < files)
	
	if (files.size() <= (unsigned)nprocs-1) {
		// Dispatch
		for (int j=1;j<nprocs;j++) {
			if (f_iter != files.end()) {
				send_int(j, 1);
				send_int(j, n_wrds);
				send_int(j, f_iter->first);
				send_str(j, f_iter->second);
				f_iter++;
				disp++;
			} else {
				send_int(j, 0);
			}
		}
		
		// Receive
		for (int j=1;j<nprocs && recv < disp;j++,recv++) {
			// # of files processed
			recv_int(j, FROM_WORKER);	// Sends 1 since we sent it only one file
			
			// Number of words
			n_wrds = recv_int(j, FROM_WORKER);
		
			// File ID
			tmp_id = recv_int(j, FROM_WORKER);
			for (int k=0;k<n_wrds;k++){
				// Word
				word = recv_str(j, FROM_WORKER);
				// Usage
				usage = recv_int(j, FROM_WORKER);
				
				cout << files[tmp_id] << "," << word << "," << usage << "\n";
			}
		}
	} else {
		// Calculate number of files to send to each slave process
		int per_proc = files.size() / (nprocs-1),				// Typical per process load
			lst_proc = nprocs - (files.size() % (nprocs-1)),	// Load for last process (if uneven)
			f_dsp;
		
		// Dispatch
		for (int j=1;j<nprocs;j++) {
			// If last process, dispatch "extra" in last process count (lst_proc)
			f_dsp = j >= lst_proc ? per_proc+1 : per_proc;
			send_int(j, f_dsp);
			
			send_int(j, n_wrds);
			
			for (int k=0;k<f_dsp;k++) {
				send_int(j, f_iter->first);
				send_str(j, f_iter->second);
				f_iter++;
			}
		}
		
		// Receive
		for (int j=1;j<nprocs;j++) {
			// Have the worker tell us how many files to send us...
			f_dsp = recv_int(j, FROM_WORKER);
			
			for (int f=0;f<f_dsp;f++) {
				// Number of words
				n_wrds = recv_int(j, FROM_WORKER);

				// File ID
				tmp_id = recv_int(j, FROM_WORKER);
				for (int k=0;k<n_wrds;k++){
					// Word
					word = recv_str(j, FROM_WORKER);
					// Usage
					usage = recv_int(j, FROM_WORKER);
					
					cout << files[tmp_id] << "," << word << "," << usage << "\n";
				}
			}
		}
	}
}

/**
 * Runs the code for the slave process which entails reading a series of files
 * and returning their results to the master process via MPI.
 */
void run_slave () {
	int file_id;
	
	// Number of files
	int fc = recv_int(MASTER, FROM_MASTER);
	
	if (fc == 0) return;
	
	// Number of words
	n_wrds = recv_int(MASTER, FROM_MASTER);
	
	map<int, string> files;
	string fn;
	
	for (int j=0;j<fc;j++) {
		// File ID
		file_id = recv_int(MASTER, FROM_MASTER);
		// Filename
		fn = recv_str(MASTER, FROM_MASTER);
		files[file_id] = fn;
	}
	
	// Send files processed to MASTER
	send_int(MASTER, files.size());
	map<int, string>::iterator f_iter;
	for (f_iter = files.begin(); f_iter != files.end(); f_iter++)
		count_words(f_iter->second, f_iter->first);
}

/**
 * Main method
 */
int main (int argc, char *argv[]) {
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &proc);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
	if (proc == MASTER) {
		double t1, t2;
		t1 = MPI_Wtime();
		run_master(argc, argv);
		t2 = MPI_Wtime();
		cout << "Time Elapsed: " << t2-t1 << " sec\n";
	} else if (proc > MASTER) {
		run_slave();
		
		MPI_Finalize();
	}
	return 0;
}
