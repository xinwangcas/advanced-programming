Homework 8
Todd Suess

This assignment uses OpenMPI to parallelize the process of finding the N-most frequently used words in text files by dividing the work among a series of machines.  The assignment is divided into 4 parts below:


[Part 1]
-Reads a simple text file given as an argument to the program q1.
-Usage: q1 -n <WORDS> <file>


[Part 2]
-Reads a series of text files in a directory and returns the results for each.
-Usage: q2 -n <WORDS> -d <DIR>


[Part 3]
-Copies files from a specified directory to each server's temp directory ("/tmp/tls209").

-There is a slight speedup by roughly 20-30 milliseconds from using the temp directory instead of NFS.  My assumption is that the NFS server has a very fast and distributed network to keep file access fast and effective however using local disk space offers a small performance boost but it isn't always consistent given that many people are accessing these machines.

-Usage: q3 -d <DIR>


[Part 4]
-Reads files specified by a URL file containing the URLs to access the files and analyzes them the same way in part 2.

-There was no speedup with this process but rather a horrible slowdown.  I put some sample text files on a portion of web space that has a dedicated 10 Mbps connection and another web space with 100 Mbps speed shared among several clients.  While it obviously doesn't compare to Lehigh's connection, the lag is considerable.  It took around 60-70 seconds to run on external networks and running from a test on Lehigh's CSE Department-provided web space (@cse.lehigh.edu) the time was around 16.5 seconds.  The presence of these bottlenecks exists between the Sunlab and the Internet vs Sunlab and the CSE Intranet.

-Example file: files.txt
-Usage: q4 -n <WORDS> -l <URLFILE>

Portions of the assignment could be tweaked for efficiency but due to time constraints, I was unable to utilize memory efficiently and some of my code may look grotesque.